module "resource_group" {
  source = "../../../../modules/resource-group"

  name = local.resource_group_name
}
